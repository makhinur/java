package com.company;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

public class DBManager {
    private Connection connection;

    public void connect() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/big_project?useUnicode=true&serverTimezone=UTC", "root","");
            System.out.println("CONNECTED");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public ArrayList<City> getAllCities() {
        ArrayList<City> cities = new ArrayList<>();
        try {
            PreparedStatement st = connection.prepareStatement("SELECT * FROM cities");
            ResultSet rs = st.executeQuery();

            while(rs.next()) {
                int id = rs.getInt("id");
                String name = rs.getString("name");
                String country = rs.getString("country");
                String shortName = rs.getString("short_name");

                cities.add(new City(id, name, country, shortName));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return cities;
    }

    public void addCity(City city) {
        try {
            PreparedStatement st = connection.prepareStatement("INSERT INTO cities(id, name, country, short_name) values(NULL,?,?,?)");
            st.setString(1, city.getName());
            st.setString(2, city.getCountry());
            st.setString(3, city.getShortName());
            st.executeUpdate();
            st.close();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void updateCity(City city) {
        try {
            PreparedStatement st = connection.prepareStatement("UPDATE cities set name = ?, country = ?, short_name = ? where id = ?");
            st.setString(1, city.getName());
            st.setString(2, city.getCountry());
            st.setString(3, city.getShortName());
            st.setInt(4, city.getId());
            st.executeUpdate();
            st.close();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void deleteCity(int id) {
        try {
            PreparedStatement st = connection.prepareStatement("DELETE FROM cities where id = ?");
            st.setLong(1, id);
            st.executeUpdate();
            st.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public ArrayList<Aircraft> getAllAircrafts() {
        ArrayList<Aircraft> aircrafts = new ArrayList<>();
        try {
            PreparedStatement st = connection.prepareStatement("SELECT * FROM aircrafts");
            ResultSet rs = st.executeQuery();

            while(rs.next()) {
                int id = rs.getInt("id");
                String name = rs.getString("name");
                String model = rs.getString("model");
                int businessClassCapacity = rs.getInt("business_class_capacity");
                int economyClassCapacity = rs.getInt("economy_class_capacity");

                aircrafts.add(new Aircraft(id, name, model, businessClassCapacity, economyClassCapacity));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return aircrafts;
    }

    public void addAircraft(Aircraft aircraft) {
        try {
            PreparedStatement st = connection.prepareStatement("INSERT INTO aircrafts(id, name, model, business_class_capacity, economy_class_capacity) values(NULL,?,?,?,?)");
            st.setString(1, aircraft.getName());
            st.setString(2, aircraft.getModel());
            st.setInt(3, aircraft.getBusinessClassCapacity());
            st.setInt(4, aircraft.getEconomyClassCapacity());
            st.executeUpdate();
            st.close();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void updateAircraft(Aircraft aircraft) {
        try {
            PreparedStatement st = connection.prepareStatement("UPDATE aircrafts set name = ?, model = ?, business_class_capacity = ?, economy_class_capacity = ? where id = ?");
            st.setString(1, aircraft.getName());
            st.setString(2, aircraft.getModel());
            st.setInt(3, aircraft.getBusinessClassCapacity());
            st.setInt(4, aircraft.getEconomyClassCapacity());
            st.setInt(5, aircraft.getId());
            st.executeUpdate();
            st.close();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void deleteAircraft(int id) {
        try {
            PreparedStatement st = connection.prepareStatement("DELETE FROM aircrafts where id = ?");
            st.setLong(1, id);
            st.executeUpdate();
            st.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public ArrayList<Flight> getAllFlights() {
        ArrayList<Flight> flights = new ArrayList<>();
        try {
            PreparedStatement st = connection.prepareStatement("SELECT * FROM flights");
            ResultSet rs = st.executeQuery();

            while(rs.next()) {
                int id = rs.getInt("id");
                int aircraftID = rs.getInt("aircraft_id");
                int departureCityID = rs.getInt("departure_city_id");
                int arrivalCityID = rs.getInt("arrival_city_id");
                String departure_time = rs.getString("departure_time");
                int economyPlacePrice = rs.getInt("economy_place_price");
                int businessPlacePrice = rs.getInt("business_place_price");

                PackageData pd = new PackageData();
                pd.setAircrafts(getAllAircrafts());
                pd.setCities(getAllCities());
                flights.add(new Flight(id, pd.getAircraftById(aircraftID), pd.getCityById(departureCityID), pd.getCityById(arrivalCityID), departure_time, economyPlacePrice, businessPlacePrice));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return flights;
    }

    public void addFlight(Flight flight) {
        try {
            PreparedStatement st = connection.prepareStatement("INSERT INTO flights(id, aircraft_id, departure_city_id, arrival_city_id, departure_time, economy_place_price, business_place_price) values(NULL,?,?,?,?,?,?)");
            st.setInt(1, flight.getAircraft().getId());
            st.setInt(2, flight.getDepartureCity().getId());
            st.setInt(3, flight.getArrivalCity().getId());
            st.setString(4, flight.getDepartureTime());
            st.setInt(5, flight.getEconomyPlacePrice());
            st.setInt(6, flight.getBusinessPlacePrice());
            st.executeUpdate();
            st.close();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void updateFight(Flight flight) {
        try {
            PreparedStatement st = connection.prepareStatement("UPDATE flights set aircraft_id = ?, departure_city_id = ?, arrival_city_id = ?, departure_time = ?, economy_place_price = ?, business_place_price = ? where id = ?");
            st.setInt(1, flight.getAircraft().getId());
            st.setInt(2, flight.getDepartureCity().getId());
            st.setInt(3, flight.getArrivalCity().getId());
            st.setString(4, flight.getDepartureTime());
            st.setInt(5, flight.getEconomyPlacePrice());
            st.setInt(6, flight.getBusinessPlacePrice());
            st.setInt(7, flight.getId());
            st.executeUpdate();
            st.close();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void deleteFlight(int id) {
        try {
            PreparedStatement st = connection.prepareStatement("DELETE FROM flights where id = ?");
            st.setLong(1, id);
            st.executeUpdate();
            st.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public ArrayList<Ticket> getAllTickets() {
        ArrayList<Ticket> tickets = new ArrayList<>();
        try {
            PreparedStatement st = connection.prepareStatement("SELECT * FROM tickets");
            ResultSet rs = st.executeQuery();

            while(rs.next()) {
                int id = rs.getInt("id");
                int flightID = rs.getInt("flight_id");
                String name = rs.getString("name");
                String surname = rs.getString("surname");
                String passportNumber = rs.getString("passport_number");
                String ticketType = rs.getString("ticket_type");

                PackageData pd = new PackageData();
                pd.setFlights(getAllFlights());
                tickets.add(new Ticket(id, pd.getFlightById(flightID), name, surname, passportNumber, ticketType));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return tickets;
    }

    public void addTicket(Ticket ticket) {
        try {
            PreparedStatement st = connection.prepareStatement("INSERT INTO tickets(id, flight_id, name, surname, passport_number, ticket_type) values(NULL,?,?,?,?,?)");
            st.setInt(1, ticket.getFlight().getId());
            st.setString(2, ticket.getName());
            st.setString(3, ticket.getSurname());
            st.setString(4, ticket.getPassportNumber());
            st.setString(5, ticket.getTicketType());
            st.executeUpdate();
            st.close();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void updateTicket(Ticket ticket) {
        try {
            PreparedStatement st = connection.prepareStatement("UPDATE tickets set flight_id = ?, name = ?, surname = ?, passport_number = ?, ticket_type = ? where id = ?");
            st.setInt(1, ticket.getFlight().getId());
            st.setString(2, ticket.getName());
            st.setString(3, ticket.getSurname());
            st.setString(4, ticket.getPassportNumber());
            st.setString(5, ticket.getTicketType());
            st.setLong(6, ticket.getId());
            st.executeUpdate();
            st.close();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void deleteTicket(int id) {
        try {
            PreparedStatement st = connection.prepareStatement("DELETE FROM tickets where id = ?");
            st.setInt(1, id);
            st.executeUpdate();
            st.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
