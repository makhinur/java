package com.company;

import java.io.Serializable;

public class Aircraft implements Serializable {
    private int id;
    private String name;
    private String model;
    private int businessClassCapacity;
    private int economyClassCapacity;

    public Aircraft() {

    }

    public Aircraft(int id, String name, String model, int businessClassCapacity, int economyClassCapacity) {
        this.id = id;
        this.name = name;
        this.model = model;
        this.businessClassCapacity = businessClassCapacity;
        this.economyClassCapacity = economyClassCapacity;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public int getBusinessClassCapacity() {
        return businessClassCapacity;
    }

    public void setBusinessClassCapacity(int businessClassCapacity) {
        this.businessClassCapacity = businessClassCapacity;
    }

    public int getEconomyClassCapacity() {
        return economyClassCapacity;
    }

    public void setEconomyClassCapacity(int economyClassCapacity) {
        this.economyClassCapacity = economyClassCapacity;
    }

    @Override
    public String toString() {
        return "Aircraft{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", model='" + model + '\'' +
                ", businessClassCapacity=" + businessClassCapacity +
                ", economyClassCapacity=" + economyClassCapacity +
                '}';
    }
}
