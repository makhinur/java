package com.company;

import java.io.Serializable;

public class Ticket implements Serializable {
    private int id;
    private Flight flight;
    private String name;
    private String surname;
    private String passportNumber;
    private String ticketType;

    public Ticket() {

    }

    public Ticket(int id, Flight flight, String name, String surname, String passportNumber, String ticketType) {
        this.id = id;
        this.flight = flight;
        this.name = name;
        this.surname = surname;
        this.passportNumber = passportNumber;
        this.ticketType = ticketType;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Flight getFlight() {
        return flight;
    }

    public void setFlight(Flight flight) {
        this.flight = flight;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSurname() {
        return surname;
    }

    public void setSurname(String surname) {
        this.surname = surname;
    }

    public String getPassportNumber() {
        return passportNumber;
    }

    public void setPassportNumber(String passportNumber) {
        this.passportNumber = passportNumber;
    }

    public String getTicketType() {
        return ticketType;
    }

    public void setTicketType(String ticketType) {
        this.ticketType = ticketType;
    }

    @Override
    public String toString() {
        return "Ticket{" +
                "id=" + id +
                ", flight=" + flight + '\'' +
                ", name='" + name + '\'' +
                ", surname='" + surname + '\'' +
                ", passportNumber='" + passportNumber + '\'' +
                ", ticketType='" + ticketType + '\'' +
                '}';
    }
}
