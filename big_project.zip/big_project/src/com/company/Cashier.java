package com.company;

import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.Scanner;

public class Cashier {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        try {
            Socket socket = new Socket("127.0.0.1", 7878);
            ObjectOutputStream outStream = new ObjectOutputStream(socket.getOutputStream());
            ObjectInputStream inStream = new ObjectInputStream(socket.getInputStream());

            while(true) {
                System.out.println("PRESS [1] TO LIST TICKETS");
                System.out.println("PRESS [2] TO ADD TICKET");
                System.out.println("PRESS [3] TO UPDATE TICKET");
                System.out.println("PRESS [4] TO DELETE TICKET");
                System.out.println("PRESS [0] TO EXIT");

                int choice = sc.nextInt();

                if(choice == 0) {
                    break;
                } else if (choice == 1) {
                    PackageData pd = new PackageData();
                    pd.setOperationType("LIST_TICKETS");
                    outStream.writeObject(pd);
                    while((pd = (PackageData) inStream.readObject()) != null) {
                        for (Ticket ticket: pd.getTickets()) {
                            System.out.println(ticket.toString());
                        }
                        break;
                    }
                } else if (choice == 2) {
                    PackageData pd = new PackageData();
                    pd.setOperationType("LIST_FLIGHTS");
                    outStream.writeObject(pd);
                    Ticket ticket = new Ticket();
                    while((pd = (PackageData) inStream.readObject()) != null) {
                        for(Flight flight: pd.getFlights()) {
                            System.out.println(flight.toString());
                        }
                        System.out.println("Insert flight ID:");
                        ticket.setFlight(pd.getFlightById(sc.nextInt()));
                        break;
                    }
                    System.out.println("Insert name:");
                    ticket.setName(sc.next());
                    System.out.println("Insert surname:");
                    ticket.setSurname(sc.next());
                    System.out.println("Insert passport number:");
                    ticket.setPassportNumber(sc.next());
                    System.out.println("Insert ticket type:\n Press [1] for Economy Class \n Press [2] for Business Class");
                    int option = sc.nextInt();
                    if(option == 1) {
                        ticket.setTicketType("ec");
                    } else if (option == 2) {
                        ticket.setTicketType("bc");
                    }
                    pd.setOperationType("ADD_TICKET");
                    pd.setTicket(ticket);
                    outStream.writeObject(pd);
                    while ((pd = (PackageData) inStream.readObject()) != null) {
                        if(pd.getOperationType().equals("ADDED")) {
                            System.out.println("TICKET successfully added");
                        } else {
                            System.out.println("Some error");
                        }
                        break;
                    }
                } else if (choice == 3) {
                    Ticket ticket = new Ticket();
                    System.out.println("Insert ticket ID:");
                    ticket.setId(sc.nextInt());
                    PackageData pd = new PackageData();
                    pd.setOperationType("LIST_FLIGHTS");
                    outStream.writeObject(pd);
                    while((pd = (PackageData) inStream.readObject()) != null) {
                        for(Flight flight: pd.getFlights()) {
                            System.out.println(flight.toString());
                        }
                        System.out.println("Insert flight ID:");
                        ticket.setFlight(pd.getFlightById(sc.nextInt()));
                        break;
                    }
                    System.out.println("Insert name:");
                    ticket.setName(sc.next());
                    System.out.println("Insert surname:");
                    ticket.setSurname(sc.next());
                    System.out.println("Insert passport number:");
                    ticket.setPassportNumber(sc.next());
                    System.out.println("Insert ticket type:\n Press [1] for Economy Class \n Press[2] for Business Class");
                    int option = sc.nextInt();
                    if(option == 1) {
                        ticket.setTicketType("ec");
                    } else if (option == 2) {
                        ticket.setTicketType("bc");
                    }
                    pd.setOperationType("UPDATE_TICKET");
                    pd.setTicket(ticket);
                    outStream.writeObject(pd);
                    while((pd = (PackageData) inStream.readObject()) != null) {
                        if(pd.getOperationType().equals("UPDATED")) {
                            System.out.println("TICKET successfully added");
                        } else {
                            System.out.println("Some error");
                        }
                        break;
                    }
                } else if (choice == 4) {
                    System.out.println("Insert ticket ID:");
                    int id = sc.nextInt();
                    Ticket ticket = new Ticket();
                    ticket.setId(id);
                    PackageData pd = new PackageData();
                    pd.setOperationType("DELETE_TICKET");
                    pd.setTicket(ticket);
                    outStream.writeObject(pd);
                    while((pd = (PackageData) inStream.readObject()) != null) {
                        if(pd.getOperationType().equals("DELETED")) {
                            System.out.println("TICKET successfully deleted");
                        } else {
                            System.out.println("Some error");
                        }
                        break;
                    }
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
