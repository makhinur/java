package com.company;

import java.io.Serializable;

public class Flight implements Serializable {
    private int id;
    private Aircraft aircraft;
    private City departureCity;
    private City arrivalCity;
    private String departureTime;
    private int economyPlacePrice;
    private int businessPlacePrice;

    public Flight() {

    }

    public Flight(int id, Aircraft aircraft, City departureCity, City arrivalCity, String departureTime, int economyPlacePrice, int businessPlacePrice) {
        this.id = id;
        this.aircraft = aircraft;
        this.departureCity = departureCity;
        this.arrivalCity = arrivalCity;
        this.departureTime = departureTime;
        this.economyPlacePrice = economyPlacePrice;
        this.businessPlacePrice = businessPlacePrice;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Aircraft getAircraft() {
        return aircraft;
    }

    public void setAircraft(Aircraft aircraft) {
        this.aircraft = aircraft;
    }

    public City getDepartureCity() {
        return departureCity;
    }

    public void setDepartureCity(City departureCity) {
        this.departureCity = departureCity;
    }

    public City getArrivalCity() {
        return arrivalCity;
    }

    public void setArrivalCity(City arrivalCity) {
        this.arrivalCity = arrivalCity;
    }

    public String getDepartureTime() {
        return departureTime;
    }

    public void setDepartureTime(String departureTime) {
        this.departureTime = departureTime;
    }

    public int getEconomyPlacePrice() {
        return economyPlacePrice;
    }

    public void setEconomyPlacePrice(int economyPlacePrice) {
        this.economyPlacePrice = economyPlacePrice;
    }

    public int getBusinessPlacePrice() {
        return businessPlacePrice;
    }

    public void setBusinessPlacePrice(int businessPlacePrice) {
        this.businessPlacePrice = businessPlacePrice;
    }

    @Override
    public String toString() {
        return "Flight{" +
                "id=" + id +
                ", aircraft=" + aircraft +
                ", departureCity=" + departureCity +
                ", arrivalCity=" + arrivalCity +
                ", departureTime='" + departureTime + '\'' +
                ", economyPlacePrice=" + economyPlacePrice +
                ", businessPlacePrice=" + businessPlacePrice +
                '}';
    }
}
