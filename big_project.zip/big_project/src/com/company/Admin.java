package com.company;

import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.Scanner;

public class Admin {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        try {
            Socket socket = new Socket("127.0.0.1", 7878);
            ObjectOutputStream outStream = new ObjectOutputStream(socket.getOutputStream());
            ObjectInputStream inStream = new ObjectInputStream(socket.getInputStream());

            while (true) {
                System.out.println("[1] Cities");
                System.out.println("[2] Flights");
                System.out.println("[3] Aircrafts");
                System.out.println("[4] Exit");
                int choice = sc.nextInt();

                if (choice == 1) {
                    while (true) {
                        System.out.println("PRESS [1] TO LIST CITIES");
                        System.out.println("PRESS [2] TO ADD CITY");
                        System.out.println("PRESS [3] TO UPDATE CITY");
                        System.out.println("PRESS [4] TO DELETE CITY");
                        System.out.println("PRESS [5] TO GO BACK");
                        choice = sc.nextInt();

                        if (choice == 1) {
                            PackageData pd = new PackageData();
                            pd.setOperationType("LIST_CITIES");
                            outStream.writeObject(pd);
                            while((pd = (PackageData) inStream.readObject()) != null) {
                                for (City city: pd.getCities()) {
                                    System.out.println(city.toString());
                                }
                                break;
                            }
                        } else if (choice == 2) {
                            System.out.println("Insert CITY:");
                            String name = sc.next();
                            System.out.println("Insert COUNTRY:");
                            String country = sc.next();
                            System.out.println("Insert CITY IATA CODE:");
                            String shortName = sc.next();
                            City newCity = new City(0, name, country, shortName.toUpperCase());
                            PackageData pd = new PackageData();
                            pd.setOperationType("ADD_CITY");
                            pd.setCity(newCity);
                            outStream.writeObject(pd);
                            while((pd = (PackageData) inStream.readObject()) != null) {
                                if(pd.getOperationType().equals("ADDED")) {
                                    System.out.println("CITY successfully added");
                                } else {
                                    System.out.println("Some error");
                                }
                                break;
                            }
                        } else if (choice == 3) {
                            System.out.println("Insert ID:");
                            int id = sc.nextInt();
                            System.out.println("Insert CITY:");
                            String name = sc.next();
                            System.out.println("Insert COUNTRY:");
                            String country = sc.next();
                            System.out.println("Insert CITY IATA CODE:");
                            String shortName = sc.next();
                            City newCity = new City(id, name, country, shortName.toUpperCase());
                            PackageData pd = new PackageData();
                            pd.setOperationType("UPDATE_CITY");
                            pd.setCity(newCity);
                            outStream.writeObject(pd);
                            while((pd = (PackageData) inStream.readObject()) != null) {
                                if(pd.getOperationType().equals("UPDATED")) {
                                    System.out.println("CITY successfully updated");
                                } else {
                                    System.out.println("Some error");
                                }
                                break;
                            }
                        } else if (choice == 4) {
                            System.out.println("Insert ID:");
                            int id = sc.nextInt();
                            City city = new City();
                            city.setId(id);
                            PackageData pd = new PackageData();
                            pd.setOperationType("DELETE_CITY");
                            pd.setCity(city);
                            outStream.writeObject(pd);
                            while((pd = (PackageData) inStream.readObject()) != null) {
                                if(pd.getOperationType().equals("DELETED")) {
                                    System.out.println("CITY successfully deleted");
                                } else {
                                    System.out.println("Some error");
                                }
                                break;
                            }
                        } else if (choice == 5){
                            break;
                        }
                    }
                } else if (choice == 2) {
                    while (true) {
                        System.out.println("PRESS [1] TO LIST FLIGHTS");
                        System.out.println("PRESS [2] TO ADD FLIGHT");
                        System.out.println("PRESS [3] TO UPDATE FLIGHT");
                        System.out.println("PRESS [4] TO DELETE FLIGHT");
                        System.out.println("PRESS [5] TO GO BACK");

                        choice = sc.nextInt();

                        if (choice == 1) {
                            PackageData pd = new PackageData();
                            pd.setOperationType("LIST_FLIGHTS");
                            outStream.writeObject(pd);
                            while((pd = (PackageData) inStream.readObject()) != null) {
                                for(Flight flight: pd.getFlights()) {
                                    System.out.println(flight.toString());
                                }
                                break;
                            }
                        } else if (choice == 2) {
                            PackageData pd = new PackageData();
                            pd.setOperationType("LIST_AIRCRAFTS");
                            outStream.writeObject(pd);
                            Flight flight = new Flight();
                            while((pd = (PackageData) inStream.readObject()) != null) {
                                for(Aircraft aircraft: pd.getAircrafts()) {
                                    System.out.println(aircraft.toString());
                                }
                                System.out.println("Insert AIRCRAFT ID from list:");
                                flight.setAircraft(pd.getAircraftById(sc.nextInt()));
                                break;
                            }
                            pd.setOperationType("LIST_CITIES");
                            outStream.writeObject(pd);
                            while((pd = (PackageData) inStream.readObject()) != null) {
                                for (City city : pd.getCities()) {
                                    System.out.println(city.toString());
                                }
                                System.out.println("Insert ID OF CITY OF DEPARTURE:");
                                flight.setDepartureCity(pd.getCityById(sc.nextInt()));
                                System.out.println("Insert ID OF CITY OF ARRIVAL:");
                                flight.setArrivalCity(pd.getCityById(sc.nextInt()));
                                break;
                            }
                            System.out.println("Insert DEPARTURE TIME:");
                            flight.setDepartureTime(sc.next());
                            System.out.println("Insert PRICE OF ECONOMY CLASS SEAT");
                            flight.setEconomyPlacePrice(sc.nextInt());
                            System.out.println("Insert PRICE OF BUSINESS CLASS SEAT");
                            flight.setBusinessPlacePrice(sc.nextInt());
                            pd.setOperationType("ADD_FLIGHT");
                            pd.setFlight(flight);
                            outStream.writeObject(pd);
                            while((pd = (PackageData) inStream.readObject()) != null) {
                                if(pd.getOperationType().equals("ADDED")) {
                                    System.out.println("FLIGHT successfully added");
                                } else {
                                    System.out.println("Some error");
                                }
                                break;
                            }
                        } else if (choice == 3) {
                            Flight flight = new Flight();
                            System.out.println("Insert ID:");
                            flight.setId(sc.nextInt());
                            PackageData pd = new PackageData();
                            pd.setOperationType("LIST_AIRCRAFTS");
                            outStream.writeObject(pd);
                            while((pd = (PackageData) inStream.readObject()) != null) {
                                for(Aircraft aircraft: pd.getAircrafts()) {
                                    System.out.println(aircraft.toString());
                                }
                                System.out.println("Choose AIRCRAFT by ID. Insert ID:");
                                flight.setAircraft(pd.getAircraftById(sc.nextInt()));
                                break;
                            }
                            pd.setOperationType("LIST_CITIES");
                            outStream.writeObject(pd);
                            while((pd = (PackageData) inStream.readObject()) != null) {
                                for (City city : pd.getCities()) {
                                    System.out.println(city.toString());
                                }
                                System.out.println("Insert ID OF CITY OF DEPARTURE:");
                                flight.setDepartureCity(pd.getCityById(sc.nextInt()));
                                System.out.println("Insert ID OF CITY OF ARRIVAL:");
                                flight.setArrivalCity(pd.getCityById(sc.nextInt()));
                                break;
                            }
                            System.out.println("Insert DEPARTURE TIME:");
                            flight.setDepartureTime(sc.next());
                            System.out.println("Insert PRICE OF ECONOMY CLASS SEAT");
                            flight.setEconomyPlacePrice(sc.nextInt());
                            System.out.println("Insert PRICE OF BUSINESS CLASS SEAT");
                            flight.setBusinessPlacePrice(sc.nextInt());
                            pd.setOperationType("UPDATE_FLIGHT");
                            pd.setFlight(flight);
                            outStream.writeObject(pd);
                            while((pd = (PackageData) inStream.readObject()) != null) {
                                if(pd.getOperationType().equals("UPDATED")) {
                                    System.out.println("FLIGHT successfully updated");
                                } else {
                                    System.out.println("Some error");
                                }
                                break;
                            }
                        } else if (choice == 4) {
                            Flight flight = new Flight();
                            System.out.println("Insert ID:");
                            flight.setId(sc.nextInt());
                            PackageData pd = new PackageData();
                            pd.setOperationType("DELETE_FLIGHT");
                            pd.setFlight(flight);
                            outStream.writeObject(pd);
                            while ((pd = (PackageData) inStream.readObject()) != null) {
                                if(pd.getOperationType().equals("DELETED")) {
                                    System.out.println("FLIGHT successfully deleted");
                                } else {
                                    System.out.println("Some error");
                                }
                                break;
                            }
                        } else if (choice == 5) {
                            break;
                        }
                    }
                } else if (choice == 3) {
                    while (true) {
                        System.out.println("PRESS [1] TO LIST AIRCRAFTS");
                        System.out.println("PRESS [2] TO ADD AIRCRAFT");
                        System.out.println("PRESS [3] TO UPDATE AIRCRAFT");
                        System.out.println("PRESS [4] TO DELETE AIRCRAFT");
                        System.out.println("PRESS [5] TO GO BACK");
                        choice = sc.nextInt();

                        if(choice == 1) {
                            PackageData pd = new PackageData();
                            pd.setOperationType("LIST_AIRCRAFTS");
                            outStream.writeObject(pd);
                            while((pd = (PackageData) inStream.readObject()) != null) {
                                for(Aircraft aircraft: pd.getAircrafts()) {
                                    System.out.println(aircraft.toString());
                                }
                                break;
                            }
                        } else if (choice == 2) {
                            System.out.println("Insert AIRCRAFT NAME:");
                            String name = sc.next();
                            System.out.println("Insert MODEL:");
                            String model = sc.next();
                            System.out.println("Insert BUSINESS CLASS SEATS CAPACITY:");
                            int businessSeatsCapacity = sc.nextInt();
                            System.out.println("Insert ECONOMY CLASS SEATS CAPACITY:");
                            int economySeatsCapacity = sc.nextInt();
                            Aircraft newAircraft = new Aircraft(0, name, model, businessSeatsCapacity, economySeatsCapacity);
                            PackageData pd = new PackageData();
                            pd.setOperationType("ADD_AIRCRAFT");
                            pd.setAircraft(newAircraft);
                            outStream.writeObject(pd);
                            while((pd = (PackageData) inStream.readObject()) != null) {
                                if(pd.getOperationType().equals("ADDED")) {
                                    System.out.println("AIRCRAFT successfully added");
                                } else {
                                    System.out.println("Some error");
                                }
                                break;
                            }
                        } else if (choice == 3) {
                            System.out.println("Insert ID:");
                            int id = sc.nextInt();
                            System.out.println("Insert AIRCRAFT NAME:");
                            String name = sc.next();
                            System.out.println("Insert MODEL:");
                            String model = sc.next();
                            System.out.println("Insert BUSINESS CLASS SEATS CAPACITY:");
                            int businessSeatsCapacity = sc.nextInt();
                            System.out.println("Insert ECONOMY CLASS SEATS CAPACITY:");
                            int economySeatsCapacity = sc.nextInt();
                            Aircraft newAircraft = new Aircraft(id, name, model, businessSeatsCapacity, economySeatsCapacity);
                            PackageData pd = new PackageData();
                            pd.setOperationType("UPDATE_AIRCRAFT");
                            pd.setAircraft(newAircraft);
                            outStream.writeObject(pd);
                            while((pd = (PackageData) inStream.readObject()) != null) {
                                if(pd.getOperationType().equals("UPDATED")) {
                                    System.out.println("AIRCRAFT successfully updated");
                                } else {
                                    System.out.println("Some error");
                                }
                                break;
                            }
                        } else if (choice == 4) {
                            System.out.println("Insert ID:");
                            int id = sc.nextInt();
                            Aircraft aircraft = new Aircraft();
                            aircraft.setId(id);
                            PackageData pd = new PackageData();
                            pd.setOperationType("DELETE_AIRCRAFT");
                            pd.setAircraft(aircraft);
                            outStream.writeObject(pd);
                            while((pd = (PackageData) inStream.readObject()) != null) {
                                if(pd.getOperationType().equals("DELETED")) {
                                    System.out.println("AIRCRAFT successfully deleted");
                                } else {
                                    System.out.println("Some error");
                                }
                                break;
                            }
                        } else if (choice == 5){
                            break;
                        }
                    }
                } else if (choice == 4){
                    break;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
