package com.company;

import java.io.Serializable;
import java.util.ArrayList;

public class PackageData implements Serializable {
    private String operationType;
    private ArrayList<City> cities;
    private City city;
    private ArrayList<Flight> flights;
    private Flight flight;
    private ArrayList<Aircraft> aircrafts;
    private Aircraft aircraft;
    private ArrayList<Ticket> tickets;
    private Ticket ticket;

    public PackageData() {

    }

    public String getOperationType() {
        return operationType;
    }

    public void setOperationType(String operationType) {
        this.operationType = operationType;
    }

    public ArrayList<City> getCities() {
        return cities;
    }

    public void setCities(ArrayList<City> cities) {
        this.cities = cities;
    }

    public City getCity() {
        return city;
    }

    public void setCity(City city) {
        this.city = city;
    }

    public ArrayList<Flight> getFlights() {
        return flights;
    }

    public void setFlights(ArrayList<Flight> flights) {
        this.flights = flights;
    }

    public Flight getFlight() {
        return flight;
    }

    public void setFlight(Flight flight) {
        this.flight = flight;
    }

    public ArrayList<Aircraft> getAircrafts() {
        return aircrafts;
    }

    public void setAircrafts(ArrayList<Aircraft> aircrafts) {
        this.aircrafts = aircrafts;
    }

    public Aircraft getAircraft() {
        return aircraft;
    }

    public void setAircraft(Aircraft aircraft) {
        this.aircraft = aircraft;
    }

    public ArrayList<Ticket> getTickets() {
        return tickets;
    }

    public void setTickets(ArrayList<Ticket> tickets) {
        this.tickets = tickets;
    }

    public Ticket getTicket() {
        return ticket;
    }

    public void setTicket(Ticket ticket) {
        this.ticket = ticket;
    }

    public Aircraft getAircraftById(int id) {
        ArrayList<Aircraft> result = new ArrayList<>();
        for (Aircraft aircraft: aircrafts) {
            if(aircraft.getId() == id) {
                result.add(aircraft);
            }
        }
        return result.get(0);
    }

    public City getCityById(int id) {
        ArrayList<City> result = new ArrayList<>();
        for (City city: cities) {
            if(city.getId() == id) {
                result.add(city);
            }
        }
        return result.get(0);
    }

    public Flight getFlightById(int id) {
        ArrayList<Flight> result = new ArrayList<>();
        for(Flight flight: flights) {
            if(flight.getId() == id) {
                result.add(flight);
            }
        }
        return result.get(0);
    }
}
