package com.company;

import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;

public class ClientHandler extends Thread {
    private Socket socket;
    private DBManager db;

    public ClientHandler(Socket socket) {
        this.socket = socket;
    }

    public void run() {
        db = new DBManager();
        db.connect();

        try {
            ObjectInputStream is = new ObjectInputStream(socket.getInputStream());
            ObjectOutputStream os = new ObjectOutputStream(socket.getOutputStream());

            PackageData message = new PackageData();
            while((message = (PackageData) is.readObject()) != null) {
                if (message.getOperationType().equals("LIST_CITIES")) {
                    PackageData pd = new PackageData();
                    pd.setCities(db.getAllCities());
                    os.writeObject(pd);
                } else if (message.getOperationType().equals("LIST_FLIGHTS")) {
                    PackageData pd = new PackageData();
                    pd.setFlights(db.getAllFlights());
                    os.writeObject(pd);
                } else if(message.getOperationType().equals("LIST_AIRCRAFTS")) {
                    PackageData pd = new PackageData();
                    pd.setAircrafts(db.getAllAircrafts());
                    os.writeObject(pd);
                } else if (message.getOperationType().equals("LIST_TICKETS")) {
                    PackageData pd = new PackageData();
                    pd.setTickets(db.getAllTickets());
                    os.writeObject(pd);
                }else if(message.getOperationType().equals("ADD_CITY")) {
                    db.addCity(message.getCity());
                    PackageData pd = new PackageData();
                    pd.setOperationType("ADDED");
                    os.writeObject(pd);
                } else if (message.getOperationType().equals("ADD_FLIGHT")) {
                    db.addFlight(message.getFlight());
                    PackageData pd = new PackageData();
                    pd.setOperationType("ADDED");
                    os.writeObject(pd);
                } else if (message.getOperationType().equals("ADD_AIRCRAFT")) {
                    db.addAircraft(message.getAircraft());
                    PackageData pd = new PackageData();
                    pd.setOperationType("ADDED");
                    os.writeObject(pd);
                } else if (message.getOperationType().equals("ADD_TICKET")) {
                    db.addTicket(message.getTicket());
                    PackageData pd = new PackageData();
                    pd.setOperationType("ADDED");
                    os.writeObject(pd);
                } else if (message.getOperationType().equals("UPDATE_CITY")) {
                    db.updateCity(message.getCity());
                    PackageData pd = new PackageData();
                    pd.setOperationType("UPDATED");
                    os.writeObject(pd);
                } else if (message.getOperationType().equals("UPDATE_FLIGHT")) {
                    db.updateFight(message.getFlight());
                    PackageData pd = new PackageData();
                    pd.setOperationType("UPDATED");
                    os.writeObject(pd);
                } else if (message.getOperationType().equals("UPDATE_AIRCRAFT")) {
                    db.updateAircraft(message.getAircraft());
                    PackageData pd = new PackageData();
                    pd.setOperationType("UPDATED");
                    os.writeObject(pd);
                } else if (message.getOperationType().equals("UPDATE_TICKET")) {
                    db.updateTicket(message.getTicket());
                    PackageData pd = new PackageData();
                    pd.setOperationType("UPDATED");
                    os.writeObject(pd);
                } else if (message.getOperationType().equals("DELETE_CITY")) {
                    db.deleteCity(message.getCity().getId());
                    PackageData pd = new PackageData();
                    pd.setOperationType("DELETED");
                    os.writeObject(pd);
                } else if(message.getOperationType().equals("DELETE_FLIGHT")) {
                    db.deleteFlight(message.getFlight().getId());
                    PackageData pd = new PackageData();
                    pd.setOperationType("DELETED");
                    os.writeObject(pd);
                } else if (message.getOperationType().equals("DELETE_AIRCRAFT")) {
                    db.deleteAircraft(message.getAircraft().getId());
                    PackageData pd = new PackageData();
                    pd.setOperationType("DELETED");
                    os.writeObject(pd);
                } else if (message.getOperationType().equals("DELETE_TICKET")) {
                    db.deleteTicket(message.getTicket().getId());
                    PackageData pd = new PackageData();
                    pd.setOperationType("DELETED");
                    os.writeObject(pd);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
