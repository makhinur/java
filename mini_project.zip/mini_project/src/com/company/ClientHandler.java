package com.company;

import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.ArrayList;

public class ClientHandler extends Thread {
    private Socket socket;
    private DBManager db;

    public ClientHandler(Socket socket) {
        this.socket = socket;
    }

    public void run() {
        db = new DBManager();
        db.connect();

        try {
            ObjectInputStream is = new ObjectInputStream(socket.getInputStream());
            ObjectOutputStream os = new ObjectOutputStream(socket.getOutputStream());
            PackageData message;

            while((message = (PackageData) is.readObject()) != null) {
                if(message.getOperationType().equals("LIST")){
                    ArrayList<Student> students = new ArrayList<>();
                    try {
                        students = db.getAllStudents();
                    } catch (Exception e) {
                        PackageData pd = new PackageData();
                        pd.setOperationType("ERROR");
                        os.writeObject(pd);
                        continue;
                    }
                    PackageData pd = new PackageData();
                    pd.setStudents(students);
                    os.writeObject(pd);

                } else if (message.getOperationType().equals("ADD")) {
                    String name = message.getStudent().getName();
                    String surname = message.getStudent().getSurname();
                    int age = message.getStudent().getAge();
                    db.addStudent(new Student (null, name, surname, age));
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}