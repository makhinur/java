package com.company;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

public class ListStudentsPage extends JPanel {
    private MainFrame parent;
    private String[] header = {"Name", "Surname", "Age"};
    private JTable table;
    private JScrollPane scrollPane;
    private JButton back;

    public ListStudentsPage(MainFrame parent) {
        this.parent = parent;
        setSize(500, 500);
        setLayout(null);

        table = new JTable();
        table.setFont(new Font("Calibri", Font.PLAIN, 12));
        table.setRowHeight(30);

        scrollPane = new JScrollPane(table);
        scrollPane.setSize(400, 300);
        scrollPane.setLocation(50, 50);
        add(scrollPane);

        back = new JButton ("BACK");
        back.setSize(130, 35);
        back.setLocation(180, 370);
        back.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                parent.getListStudentsPage().setVisible(false);
                parent.getMainMenuPage().setVisible(true);
            }
        });
        add(back);
    }

    public void generateTable(ArrayList<Student> students) {
        Object data[][] = new Object [students.size()][3];

        for(int i = 0; i < students.size(); i ++) {
            data[i][0] = students.get(i).getName();
            data[i][1] = students.get(i).getSurname();
            data[i][2] = students.get(i).getAge();
        }

        DefaultTableModel model = new DefaultTableModel(data, header);
        table.setModel(model);
    }
}
