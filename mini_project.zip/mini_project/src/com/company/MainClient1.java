package com.company;

import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.ArrayList;

public class MainClient1 {

    public static MainFrame mainFrame;
    public static Socket socket;
    public static ObjectOutputStream outStream;
    public static ObjectInputStream inStream;

    public static void main(String[] args) {
        mainFrame = new MainFrame();
        mainFrame.setVisible(true);
    }

    public static void connectToServer() {
        try {
            socket = new Socket("127.0.0.1", 8080);
            outStream = new ObjectOutputStream(socket.getOutputStream());
            inStream = new ObjectInputStream((socket.getInputStream()));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void sendStudentToServer(Student student) {
        PackageData pd = new PackageData();
        pd.setOperationType("ADD");
        pd.setStudent(student);
        try {
            outStream.writeObject(pd);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static ArrayList<Student> getStudentsFromServer() {
        PackageData pd = new PackageData();
        pd.setOperationType("LIST");
        ArrayList<Student> students = new ArrayList<>();
        try {
            outStream.writeObject(pd);
            while ((pd = (PackageData) inStream.readObject()) != null) {
                if(pd.getOperationType() != null && pd.getOperationType().equals("ERROR")){
                    System.out.println("Some error");
                } else {
                    for (Student s : pd.getStudents()) {
                        Long id = s.getId();
                        String name = s.getName();
                        String surname = s.getSurname();
                        int age = s.getAge();
                        students.add(new Student(id, name, surname, age));
                    }
                }
                break;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return students;
    }
}

