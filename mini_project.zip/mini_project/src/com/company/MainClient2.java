package com.company;

import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.ArrayList;

public class MainClient2 {

    public static MainFrame mainFrame;
    public static Socket socket;
    public static ObjectOutputStream outStream;
    public static ObjectInputStream inStream;

    public static void main(String[] args) {
        mainFrame = new MainFrame();
        mainFrame.setVisible(true);
    }
}

