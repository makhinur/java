package com.company;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

public class MainMenu extends JPanel {

    private MainFrame parent;
    private JButton addStudent;
    private JButton listStudents;
    private JButton exit;

    public MainMenu(MainFrame parent) {
        this.parent = parent;
        setSize(500, 500);
        setLayout(null);

        addStudent = new JButton("ADD STUDENT");
        addStudent.setSize(300, 35);
        addStudent.setLocation(100, 150);
        addStudent.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                parent.getMainMenuPage().setVisible(false);
                parent.getAddStudentPage().setVisible(true);
            }
        });
        add(addStudent);

        listStudents = new JButton("LIST STUDENTS");
        listStudents.setSize(300, 35);
        listStudents.setLocation(100, 200);
        listStudents.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                ArrayList<Student> students = MainClient1.getStudentsFromServer();
                parent.getListStudentsPage().generateTable(students);
                parent.getMainMenuPage().setVisible(false);
                parent.getListStudentsPage().setVisible(true);
            }
        });
        add(listStudents);

        exit = new JButton("EXIT");
        exit.setSize(300, 35);
        exit.setLocation(100, 250);
        exit.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                System.exit(0);
            }
        });
        add(exit);
    }
}