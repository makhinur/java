package com.company;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ConnectionPage extends JPanel {
    private MainFrame parent;

    private JLabel ipLabel;
    private JLabel portLabel;
    private JTextField ipField;
    private JTextField portField;
    private JButton connectButton;

    public ConnectionPage(MainFrame parent) {
        this.parent = parent;

        setSize(500,500);
        setLayout(null);

        ipLabel = new JLabel("IP:");
        ipLabel.setSize(50, 35);
        ipLabel.setLocation(120, 100);
        add(ipLabel);

        ipField = new JTextField();
        ipField.setSize(250, 35);
        ipField.setLocation(140, 100);
        add(ipField);

        portLabel = new JLabel("PORT:");
        portLabel.setSize(50, 35);
        portLabel.setLocation(100, 160);
        add(portLabel);

        portField = new JTextField();
        portField.setSize(250, 35);
        portField.setLocation(140, 160);
        add(portField);

        connectButton = new JButton("CONNECT");
        connectButton.setSize(250, 35);
        connectButton.setLocation(120, 300);
        connectButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                String ip = ipField.getText();
                int port = Integer.parseInt(portField.getText());

                if(port == Server.getPort()){
                    parent.getConnectionPage().setVisible(false);
                    parent.getMainMenuPage().setVisible(true);
                    MainClient1.connectToServer();
                }
            }
        });
        add(connectButton);
    }
}
