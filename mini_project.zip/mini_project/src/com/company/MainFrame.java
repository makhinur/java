package com.company;

import javax.swing.*;

public class MainFrame extends JFrame {

    private ConnectionPage connectionPage;
    private MainMenu mainMenuPage;
    private AddStudentPage addStudentPage;
    private ListStudentsPage listStudentsPage;

    public MainFrame() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setTitle("STUDENT APPLICATION");
        setSize(500, 500);
        setLayout(null);

        connectionPage = new ConnectionPage(this);
        connectionPage.setVisible(true);
        add(connectionPage);

        mainMenuPage = new MainMenu(this);
        mainMenuPage.setVisible(false);
        add(mainMenuPage);

        addStudentPage = new AddStudentPage(this);
        addStudentPage.setVisible(false);
        add(addStudentPage);

        listStudentsPage = new ListStudentsPage(this);
        listStudentsPage.setVisible(false);
        add(listStudentsPage);
    }

    public ConnectionPage getConnectionPage() {
        return connectionPage;
    }

    public MainMenu getMainMenuPage() {
        return mainMenuPage;
    }

    public AddStudentPage getAddStudentPage() {
        return addStudentPage;
    }

    public ListStudentsPage getListStudentsPage() {
        return listStudentsPage;
    }
}