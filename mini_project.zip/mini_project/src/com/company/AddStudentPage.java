package com.company;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class AddStudentPage extends JPanel {
    private MainFrame parent;
    private JLabel name;
    private JLabel surname;
    private JLabel age;
    private JTextField nameField;
    private JTextField surnameField;
    private JTextField ageField;
    private JButton add;
    private JButton backButton;

    public AddStudentPage(MainFrame parent) {
        this.parent = parent;
        setSize(500, 500);
        setLayout(null);

        name = new JLabel("NAME:");
        name.setSize(60, 35);
        name.setLocation(100,100);
        add(name);

        surname = new JLabel("SURNAME:");
        surname.setSize(80, 35);
        surname.setLocation(72, 160);
        add(surname);

        age = new JLabel ("AGE:");
        age.setSize(70, 30);
        age.setLocation(110, 220);
        add(age);

        nameField = new JTextField();
        nameField.setSize(250, 35);
        nameField.setLocation(150, 100);
        add(nameField);

        surnameField = new JTextField();
        surnameField.setSize(250, 35);
        surnameField.setLocation(150, 160);
        add(surnameField);

        ageField = new JTextField();
        ageField.setSize(250, 35);
        ageField.setLocation(150, 220);
        add(ageField);

        add = new JButton("ADD");
        add.setSize(130, 35);
        add.setLocation(120, 300);
        add.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String name = nameField.getText();
                String surname = surnameField.getText();
                int age = Integer.valueOf(ageField.getText());
                if(!name.equals("") && !surname.equals("") && age!=0) {
                    MainClient1.sendStudentToServer(new Student(null, name, surname, age));
                    nameField.setText("");
                    surnameField.setText("");
                    ageField.setText("");
                }
            }
        });
        add(add);

        backButton = new JButton ("BACK");
        backButton.setSize(130, 35);
        backButton.setLocation(260, 300);
        backButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                parent.getAddStudentPage().setVisible(false);
                parent.getMainMenuPage().setVisible(true);
            }
        });
        add(backButton);
    }
}